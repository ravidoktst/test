$(function() {
                $('#ei-slider').eislideshow({
          animation     : 'center',
          autoplay      : true,
          slideshow_interval  : 3000,
          titlesFactor    : 0
                });
            });