<?php
if($_SERVER["REQUEST_METHOD"] == "POST")
{
define('bd_vorota', true); 
include("../block/db_connect.php"); 

          $delete = mysql_query("DELETE FROM category WHERE id = '{$_POST["id"]}'",$link); 
          echo "delete";   

}
?>